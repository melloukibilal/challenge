import os
import pandas as pd
import numpy as np
from sklearn.impute import SimpleImputer

class FeatureExtractor(object):
    def __init__(self):
        pass

    def fit(self, X_df, y_array):
        pass

    def transform(self, X_df):
        X_df.user_device = pd.factorize(X_df.user_device)[0]
        X_df.user_operating_system = pd.factorize(X_df.user_operating_system)[0]
        X_df.reset_index(inplace=True)
        X_df.drop(columns=["index"],inplace=True)
        imp_mean = SimpleImputer(missing_values=np.nan, strategy='mean')
        mean_strategy = imp_mean.fit_transform(np.array(X_df.average_seconds_played).reshape(-1,1))
        X_df.average_seconds_played = mean_strategy
        X = np.array(X_df)
        return X