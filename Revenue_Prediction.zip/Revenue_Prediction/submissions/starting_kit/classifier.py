from sklearn.ensemble  import RandomForestClassifier
from sklearn.base import BaseEstimator


class Classifier(BaseEstimator):
    def __init__(self):
        self.reg = RandomForestClassifier(class_weight="balanced")

    def fit(self, X, y):
        self.reg.fit(X, y)

    def predict_proba(self, X):
        return self.reg.predict_proba(X)