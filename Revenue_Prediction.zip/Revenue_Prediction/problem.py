import os
import numpy as np
import pandas as pd
import rampwf as rw
from sklearn.metrics import balanced_accuracy_score
from rampwf.score_types.base import BaseScoreType
from sklearn.model_selection import StratifiedKFold

problem_title = 'revenue gain prediction '
_target_column_name = 'revenue'
_prediction_label_names=[0,1]

Predictions = rw.prediction_types.make_multiclass(
    label_names=_prediction_label_names)

class Revenue_error(BaseScoreType):
    is_lower_the_better = False
    def __init__(self, name='balanced accuracy', precision=2):
        self.name = name
        self.precision = precision

    def __call__(self, y_true, y_pred):
        if isinstance(y_true, pd.Series):
            y_true = y_true.values
        
        y_pred = list(map(lambda x : np.argmax(x),y_pred))
        y_true = list(map(lambda x : np.argmax(x),y_true))
        return balanced_accuracy_score(y_true,y_pred)

workflow = rw.workflows.FeatureExtractorClassifier()

score_types = [
    Revenue_error(),
]


def get_cv(X, y):
    cv = StratifiedKFold(n_splits=3, random_state=42)
    return cv.split(X, y)


def _read_data(path, f_name,Test=False):
    data_ = pd.read_csv(os.path.join(path, 'data', f_name), low_memory=False,
                       compression='zip')
    data = data_.copy()
    data.dropna(subset=["user_device"],axis=0,inplace=True)
    def revenue(number):
        if number==0:
            return 0
        else:
            return 1
    
    data['revenue'] = data['revenue'].map(revenue)
    Y = data[_target_column_name].values
    X = data.drop(_target_column_name, axis=1)
    
    if Test:
        return X[::10], Y[::10]
    else:
        return X[::3], Y[::3]


def get_train_data(path='.'):
    f_name = 'aft100k.csv.zip'
    return _read_data(path, f_name)


def get_test_data(path='.'):
    f_name = 'aft100k.csv.zip'
    return _read_data(path, f_name,Test=True)
